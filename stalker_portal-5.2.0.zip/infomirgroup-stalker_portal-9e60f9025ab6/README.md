## Middleware Stalker

[Project description](http://www.infomir.eu/eng/products/free-middleware-stalker/)

[Wiki](http://wiki.iptv.infomir.com.ua/doku.php/en:stalker:start)

[Installation guide](http://wiki.iptv.infomir.com.ua/doku.php/en:stalker:install_and_configure)

[User group](https://groups.google.com/forum/#!forum/stalker-middleware)
