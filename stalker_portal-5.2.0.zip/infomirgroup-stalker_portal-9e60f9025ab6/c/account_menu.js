(function(){

    var submenu = module.account_menu || [];

    main_menu.add(word['account_info_title'], submenu, 'mm_ico_account.png', '', {"layer_name" : "account_menu"});

})();

loader.next();